jQuery(document).ready(function($) {   
$('#slider').cycle({   
          fx:    'fade',  //特效           speed:  7500,
          timeout:  7200,
          random:  1
         });
 });