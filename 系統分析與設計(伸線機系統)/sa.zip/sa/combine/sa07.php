<!DOCTYPE HTML>
<html>
<head>
<link rel=stylesheet type="text/css" href="css/sa4.css">
<?php
    $link = mysqli_connect ( 'localhost' , 'root' , '1234' ) ;
	mysqli_select_db($link, 'sa'); 
	$arraylist = array();
	$arraylist2 = array();
	
	//mysqli_query($link, "set names 'utf8'");
	$sql = "SELECT * FROM `control`";
	$i = 0 ;
    $forerrortemp = mysqli_query( $link, $sql ) ;
	  if ( $forerrortemp == false )
        echo "SELECT Error!!!...<br>";
	  while ( $row = mysqli_fetch_array( $forerrortemp ) ) {
		
        $reddata = $row['red'];
		$yellowdata = $row['yellow'];
		$greendata = $row['green'];
		$purpledata = $row['purple'];
      } // while
	  
?>
<script type="text/javascript">

window.onload = function () {
	var reddata = <?php echo $reddata ?>;
	var yellowdata = <?php echo $yellowdata ?>;
	var greendata = <?php echo $greendata ?>;
	var purpledata = <?php echo $purpledata ?>;
	var chart = new CanvasJS.Chart("chartContainer",
	{
		
		legend: {
			maxWidth: 10550,
			itemWidth: 420
		},
		data: [
		{

			
			type: "pie",
			showInLegend: true,
			legendText: "{indexLabel}",
			dataPoints: [
				{ y: yellowdata/60, indexLabel: "需注意狀況(分鐘)" },
				{ y: reddata/60, indexLabel: "停機中(分鐘)" },
				{ y: greendata/60, indexLabel: "正常運轉(分鐘)" },		
				{ y: purpledata/60, indexLabel: "異常狀況(分鐘)"},
			]
			
			 
		}
		]
		
		
	});
	chart.render();
}
</script>
<script type="text/javascript" src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</head>
<body>
<div id="chartContainer" style="height: 600px; width: 100%;"></div>
</body>
</html>