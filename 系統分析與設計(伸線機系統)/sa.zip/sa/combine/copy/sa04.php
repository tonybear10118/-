
<!DOCTYPE html>
<head>
<title></title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Visitors Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script src="https://code.highcharts.com/highcharts.js"></script>
<script src="https://code.highcharts.com/modules/exporting.js"></script>

<!-- bootstrap-css -->
<link rel="stylesheet" href="css/bootstrap.min.css" >
<!-- //bootstrap-css -->
<!-- Custom CSS -->
<link href="css/style.css" rel='stylesheet' type='text/css' />
<link href="css/style-responsive.css" rel="stylesheet"/>
<!-- font CSS -->
<link href='//fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
<!-- font-awesome icons -->
<link rel="stylesheet" href="css/font.css" type="text/css"/>
<link href="css/font-awesome.css" rel="stylesheet"> 
<link rel="stylesheet" href="css/morris.css" type="text/css"/>
<!-- calendar -->
<link rel="stylesheet" href="css/monthly.css">
<!-- //calendar -->
<!-- //font-awesome icons -->
<link rel=stylesheet type="text/css" href="css/sa4.css">

<script>
  function Clear() {  //清除上一筆資料
    document.getElementById( 'temper' ).innerHTML='';
	document.getElementById( 'speed' ).innerHTML='';
	document.getElementById( 'transfer' ).innerHTML='';
	document.getElementById( 'light' ).innerHTML='';
	document.getElementById( 'input' ).innerHTML='';
	document.getElementById( 'inputmeter' ).innerHTML='';
	document.getElementById( 'output' ).innerHTML='';
	document.getElementById( 'outputmeter' ).innerHTML='';
	document.getElementById( 'status' ).innerHTML='';
	document.getElementById( 'time' ).innerHTML='';
  }  // Clear()
</script>

</head>
<body>
<section id="container">
<!--header start-->
<header class="header fixed-top clearfix">
<!--logo start-->
<div class="brand">
    <a href="index.html" class="logo">
        伸線機
    </a>
    <div class="sidebar-toggle-box">
        <div class=""></div>
    </div>
</div>
<!--logo end-->

<div class="top-nav clearfix">
    <!--search & user info start-->
    <ul class="nav pull-right top-menu">
        <li>
            <input type="text" class="form-control search" placeholder=" Search">
        </li>
        <!-- user login dropdown start-->
        <li class="dropdown">
            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                <img alt="" src="images/2.png">
                <span class="username">員工</span>
                <b class="caret"></b>
            </a>
            
        </li>
        <!-- user login dropdown end -->
       
    </ul>
    <!--search & user info end-->
</div>
</header>
<!--header end-->
<!--sidebar start-->
<aside>
    <div id="sidebar" class="nav-collapse">
        <!-- sidebar menu start-->
        <div class="leftside-navigation">
            <ul class="sidebar-menu" id="nav-accordion">
                <li>
                    <a class="active" href="index.html">
                        <i class=""></i>
                        <span>首頁</span>
                    </a>
                </li>
                <li>
                    <a class="active" href="sa06.html" target="_blank">
                        <i class=""></i>
                        <span>歷程紀錄</span>
                    </a>
                </li>
                <li>
                    <a class="active" href="sa04.html">
                        <i class=""></i>
                        <span>品質管控</span>
                    </a>
                </li>
            </ul>            </div>
        <!-- sidebar menu end-->
    </div>
</aside>
<!--sidebar end-->
<!--main content start-->
<section id="main-content">
    <section class="wrapper">
        <!-- //market-->
        <div class="market-updates">
            <div class="col-md-3 market-update-gd">
                <div class="market-update-block clr-block-2">
                    <div class="col-md-4 market-update-right">
                        <i class=""> </i>
                    </div>
                     <div class="col-md-8 market-update-left">
                     <h4>溫度</h4>
                    <h3 id="temper">23</h3>
                  </div>
                  <div class="clearfix"> </div>
                </div>
            </div>
            <div class="col-md-3 market-update-gd">
                <div class="market-update-block clr-block-1">
                    <div class="col-md-4 market-update-right">
                        <i class="" ></i>
                    </div>
                    <div class="col-md-8 market-update-left">
                    <h4>線速</h4>
                        <h3 id="speed">23</h3>
                    </div>
                   
                  <div class="clearfix"> </div>
                </div>
            </div>
            <div class="col-md-3 market-update-gd">
                <div class="market-update-block clr-block-3">
                    <div class="col-md-4 market-update-right">
                        <i class=""></i>
                    </div>
                    <div class="col-md-8 market-update-left">
                        <h4>機台狀況</h4>
                        <h3 id="status">23</h3>
                    </div>
                  <div class="clearfix"> </div>
                </div>
            </div>
            <div class="col-md-3 market-update-gd">
                <div class="market-update-block clr-block-4">
                    <div class="col-md-4 market-update-right">
                        <i class="" aria-hidden="true"></i>
                    </div>
                    <div class="col-md-8 market-update-left">
                        <h4>燈號</h4>
                        <h2>.</h2>
                        <h3 id = "light"><img id="lightball" src="img/purple.png"></h3>
                        
                    </div>
                  <div class="clearfix"> </div>
                </div>
            </div>
           <div class="clearfix"> </div>
        </div>  
        <!-- //market-->
       
                                    
                                            
                                        
                                

                   
                 <table class="table1">   
                <tr id="td"><td id="input">投入軸型號</td>
                <td name="inrollname"></td>
                </tr>
        <tr id="td"><td id="inputmeter">投入軸計米</td>
            <td name="inrolllong"></td>
        </tr> 
        <table class="table3">
        <tr id="td"><td id="output">產出軸型號</td>
        <td name="outrollname"></td>
    </tr>
    <tr id="td"><td id="outputmeter">產出軸計米</td>
    <td name="outrolllong"></td>
</tr>
  </table>                             

<table class="table2">
<tr id="td"><td id="transfer">機台狀況</td>
<td name="condition"></td>
</tr>

<tr id="td"><td id="time">時間</td>
<td name="time"></td>
</tr>
</table>
<div id="containerr" style="min-width: 310px; height: 400px; margin: 0 auto"></div>
<script>
    $.getJSON('https://www.highcharts.com/samples/data/jsonp.php?filename=usdeur.json&callback=?', function(data) {

  Highcharts.chart('containerr', {
    chart: {
      zoomType: 'x'
    },
    title: {
      text: '線速與時間的關係'
    },
    subtitle: {
      text: document.ontouchstart === undefined ?
        'Click and drag in the plot area to zoom in' : 'Pinch the chart to zoom in'
    },
    xAxis: {
      type: 'datetime'
    },
    yAxis: {
      title: {
        text: 'Exchange rate'
      }
    },
    legend: {
      enabled: false
    },
    plotOptions: {
      area: {
        fillColor: {
          linearGradient: {
            x1: 0,
            y1: 0,
            x2: 0,
            y2: 1
          },
          stops: [
            [0, Highcharts.getOptions().colors[0]],
            [1, Highcharts.Color(Highcharts.getOptions().colors[0]).setOpacity(0).get('rgba')]
          ]
        },
        marker: {
          radius: 2
        },
        lineWidth: 1,
        states: {
          hover: {
            lineWidth: 1
          }
        },
        threshold: null
      }
    },

    series: [{
      type: 'area',
      name: '線速',
      data: data
    }]
  });
});
</script>
  <?php
   
    function Dataformat( $num ) {
      $hour = floor( $num / 3600 );
      $minute = floor( ( $num - 3600 * $hour ) / 60 );
      $second = floor( ( ( $num - 3600 * $hour ) - 60 * $minute ) % 60 );
	  
	  
	  if ( $hour < 10 )
	    ( string ) $hour = "0".$hour ;
	
	  if ( $minute < 10 )
	    ( string ) $minute = "0".$minute ;
	
	  if ( $second < 10 )
	    ( string ) $second = "0".$second ;
	  
      return $hour.':'.$minute.':'.$second;
	} // Dataformat()
	
	function PushArrayIntoDB( &$dataarray, &$dataindex, &$obj ) {
      if ( isset($obj['data']) == true )
        $dataarray[$dataindex] = $obj['data']; 
	  else { 
	    echo "模擬器炸掉啦!!!!!<br>";
	  } // else
      $dataindex++;

	} // PushArrayIntoDB()
	
	function FormatArray( &$dataarray ) { 
	  $i = 0 ; 
	  while ( $i < count( $dataarray ) ) {
		$dataarray[$i] = "";
	    $i++;
	  } // while
	} // FormatArray()
	
	
	function Simulation( &$dataarray, $startsecend ) {
      set_time_limit(0);
	  $link = mysqli_connect ( 'localhost' , 'root' , '1234' ) ;
	  mysqli_select_db($link, 'sa');
	  $timetemp = Dataformat( $startsecend ) ;
	  
	  $sql = "SELECT * FROM `simulation` WHERE time = '$timetemp' " ;
	  $forerrortemp = mysqli_query( $link, $sql ) ;
	  if ( $forerrortemp == false )
        echo "SELECT Error!!!...<br>";
	  while ( $row = mysqli_fetch_array( $forerrortemp ) ) {
        $dataarray[0] =  $row['Time'];
		$dataarray[1] =  $row['C11_I1_Meter'];
		$dataarray[2] =  $row['C11_I1_Position'];
		$dataarray[3] =  $row['C11_O1_Meter'];
		$dataarray[4] =  $row['C11_O1_Position'];
		$dataarray[5] =  $row['C11_Thermal'];
      } // while
	} // Simulation()
	
	
	function Machine( &$dataarray, $startsecend, $insert ) {
      // 抓取模擬器資料部分
	  // 寫成一個函數想抓啥就抓啥之後的演算法比較好算 ， 如果insert == true的話就是要insert進資料庫其餘不用
	  // $dataarray[0] = time
	  // $dataarray[1] = C11_I1_Meter
	  // $dataarray[2] = C11_I1_Position
	  // $dataarray[3] = C11_O1_Meter
	  // $dataarray[4] = C11_O1_Position
	  // $dataarray[5] = C11_Thermal

	  $simulatoractive = true ; // default it is active
	  set_time_limit(0); // 不受時間限制
      $link = mysqli_connect ( 'localhost' , 'root' , '1234' ) ;
	  mysqli_select_db($link, 'sa'); 
      
	  $i = $startsecend ; // 讀取資料用的秒數
	  $dataindex = 0 ; // 陣列的INDEX
	  $dataarray = array(); // 準備存進SQL的陣列  	
		// 抓取TIME && C11_I1_METER
	    $url = "http://etouch20.cycu.edu.tw:5146/simone/read/?mid=%E8%B3%87%E7%AE%A1%E4%B8%89C11%E4%BC%B8%E7%B7%9A%E6%A9%9F&sid=C11-I1-Meter&time=";
	    $time = Dataformat( $i ) ;
		$c11_i1_meter= file_get_contents( $url.$time );
		$obj = json_decode( $c11_i1_meter, true ); // 轉成陣列
		foreach( $obj as $key=>$value ) { // 把陣列的值取出來
          $dataarray[$dataindex] = $value;
		  $dataindex++;
        } // foreach
		
		
		// 抓取C11_I1_POSITION
	    $url = "http://etouch20.cycu.edu.tw:5146/simone/read/?mid=資管三C11伸線機&sid=C11-I1-Position&time=";
	    $time = Dataformat( $i ) ;
		$c11_i1_position= file_get_contents( $url.$time );
		$obj = json_decode( $c11_i1_position, true ); // 轉成陣列
		
		// 把陣列的值取出來
		PushArrayIntoDB( $dataarray, $dataindex, $obj ) ;
     
	    // 抓取C11-O1-Meter
	    $url = "http://etouch20.cycu.edu.tw:5146/simone/read/?mid=資管三C11伸線機&sid=C11-O1-Meter&time=";
	    $time = Dataformat( $i ) ;
		$c11_o1_meter= file_get_contents( $url.$time );
		$obj = json_decode( $c11_o1_meter, true ); // 轉成陣列
		
		// 把陣列的值取出來
		PushArrayIntoDB( $dataarray, $dataindex, $obj ) ;
				
		
	    // 抓取C11-O1-Position
	    $url = "http://etouch20.cycu.edu.tw:5146/simone/read/?mid=資管三C11伸線機&sid=C11-O1-Position&time=";
	    $time = Dataformat( $i ) ;
		$c11_o1_position = file_get_contents( $url.$time );
		$obj = json_decode( $c11_o1_position, true ); // 轉成陣列
		
		// 把陣列的值取出來
		PushArrayIntoDB( $dataarray, $dataindex, $obj ) ;
		
	    // 抓取C11-Thermal
	    $url = "http://etouch20.cycu.edu.tw:5146/simone/read/?mid=資管三C11伸線機&sid=C11-Thermal&time=";
	    $time = Dataformat( $i ) ;
		$c11_thermal = file_get_contents( $url.$time );
		$obj = json_decode( $c11_thermal, true ); // 轉成陣列
		
		// 把陣列的值取出來
		PushArrayIntoDB( $dataarray, $dataindex, $obj ) ;
		
		
        
		if ( $insert == true ) { // 如果為true的話才要輸入進資料庫
		    // `
			/*
			$sql = " INSERT INTO `C11` (`Time`, `C11_I1_Meter`, `C11_I1_Position`, `C11_O1_Meter`, `C11_O1_Position`, `C11_Thermal` ) 
		         VALUES ( '$dataarray[0]', '$dataarray[1]', '$dataarray[2]', '$dataarray[3]', '$dataarray[4]', '$dataarray[5]' ) " ;  
			if ( mysqli_query( $link, $sql ) == false )
		      echo "Insert Error!!!...<br>";
		  */
		} // if insert == true
		
		
		mysqli_close( $link );
	} // Machine()
	
	function Speed( &$dataarray, &$countmeter, $speed, &$speedsecend, &$workstartornot, $startsecend ) { // 此秒的資料陣列、要比對變動的線段長度、速度、計算到下次線段變動後的秒數家總、是否開始生產電纜了
	  // 看要花多少秒從自己的公尺數變動到下一個公尺數
	  // 8秒一公尺
	  // 6 5 4 3 
	  // bug是0秒的時候無法計算 ( 加上整備的過程，過程中公尺數一直都是0 )
	  
	  
	  
	  $nowmeter = ( int ) $dataarray[3] ; // 現在的產出線段長度
	  if ( $dataarray[2] != "0" && $dataarray[4] != "0" &&
           $dataarray[1] != "0" && $dataarray[3] != "0" ) { // 當產出軸跟投入軸都有的時候
	    if ( $countmeter == -1 ) { // 第一次進來要下錨
	      $countmeter = $nowmeter ;
		  $speedsecend = 1 ; // 第一秒
		  $workstartornot = true ; // 代表生產工作開始了
		  return $speed ;
	    } // if 
	  
	    else if ( $countmeter != -1 ) { // 已經下錨了
	      if ( $nowmeter == $countmeter ) {
	        $speedsecend++ ; // 要計算的秒數增加
		    return $speed; // 線速保持不辨，因為公尺數並無增加
		  } // if
		
		  else { // 公尺數變動了，開始計算變動之前到後花的秒數
	        // 每$speedsecend 秒有一公尺的線
		    // 每秒可產出 1 / $speedsecend 公尺
		    // 再乘以60 等於每分鐘可以產 多少公尺就可以算出分鐘線速
		    $speed = ( double ) ( $nowmeter - $countmeter ) / ( double ) $speedsecend ;
		    $speed *= 60 * 60 ; // 每小時線速
			if ( $speed < 0 )
			  $speed = 0 - $speed ; // 取正數		  		    
		    $countmeter = $nowmeter ; // 把錨reset
		    $speedsecend = 1 ;
		    return $speed ;
		  } // else
	    }  // else if
   
      } // if $dataarray[2] != "0" && $dataarray[4] != "0"
	  
	  
	  // 以下的nowmeter都等於0
	  
	  
	  else {  // 沒有產出軸
	    $countmeter = -1 ;
		return 0 ;
	  } // else 
		  

	
	} // Speed()
	
	
	
	function CatchSpeed( $startsecend ) {
	  
	  ( string ) $startsecend = Dataformat( $startsecend );
	  $fortranstemp = 0.0; // 站存資料用而已
      $link = mysqli_connect ( 'localhost' , 'root' , '1234' ) ;
	  mysqli_select_db($link, 'sa'); 
	  
	  $sql = " SELECT `speed` FROM `speed` WHERE time = '$startsecend' "; 
	  $forspeedtemp = mysqli_query( $link, $sql ) ;
	  if ( $forspeedtemp == false )
        echo "SELECT Speed Error!!!...<br>";
	  $speedtemp = mysqli_fetch_array( $forspeedtemp ) ;
      $fortranstemp = $speedtemp['speed']; // 到這行為止才抓到現在的線速資料
	  if ( $fortranstemp == NULL )
	    $fortranstemp = 0 ;
	  return $fortranstemp ;
	} // CatchSpeed()
	
	
	function Transfer( $dataarray, &$inputmeter, &$inputmetersecend, &$speedsum, $startsecend, $transfer, &$counttransfer, &$counttransfersecend ) {
	  // 參數說明：
	  // 算他們的平均線速 * 投入計米變動
	  // thoughts :
	  // 
  
  
  
  //////////////////////////////////////////////////////////////////
	  
	  //$dataarray, &$inputmeter, &$inputmetersecend, &$speedsum, $startsecend, $transfer, &$counttransfer, &$counttransfersecend
	  $nowinputmeter = ( int ) $dataarray[1] ;
	  if ( ( $dataarray[2] != "0" && $dataarray[4] != "0" ) || 
	       ( $dataarray[2] == "0" && $dataarray[4] != "0" ) ) {
		  
		  
        // 轉換率會用到的線速部分
		if ( $counttransfer == -1 ) {
		  $counttransfer = ( int ) $dataarray[3] ;
		  $counttransfersecend = 1 ;
		} // if`
		
	    else { // countmeter != -1 均速要用
		  if ( $counttransfer == ( int ) $dataarray[3] )
		    $counttransfersecend++;
		  else if ( $counttransfer != ( int ) $dataarray[3] ) {
		    $speedsum +=  ( CatchSpeed( $startsecend ) * $counttransfersecend ) ;
			
			$counttransfer = ( int ) $dataarray[3] ;
			$counttransfersecend = 1 ;
		  } // if
		} // else
	  
	  
	  
	  
        // 轉換率部分
		if ( $inputmeter == -1 ) { // 第一次近來下錨
	      $inputmeter = $nowinputmeter;
		  $inputmetersecend = 1 ;
		  return $transfer ; // 轉換率未知
		}  // if 第一筆
		  
		else { // 第二次以上
		
	      if ( $inputmeter == $nowinputmeter ) { // 沒變化
		    $inputmetersecend++;
			return $transfer ;
		  } // if 沒變化
		  
		  else { // 投入公尺變動了
		    // 精華 ： 平均線速 * 投入計米變動秒數 = 轉換率
			$temp = ( double ) ( ( double ) $speedsum / ( double ) $inputmetersecend / 3600 ) * $inputmetersecend ;
			if ( $temp < 0 )
		      $temp = 0 - $temp;
		  
		    $inputmeter = $nowinputmeter; // 把錨RESET
			$inputmetersecend = 1 ;
			$speedsum = 0 ; // 重新
			$counttransfersecend = 1 ;
		    return $temp;
		  }// else
		} // else 第二筆以上
	  
	  } // if 皆有軸
	  
	  else {
		$inputmetersecend = 0 ; 
		$inputmeter = -1 ;
		$transfer = 0 ;
		$speedsum = 0 ;
		$counttransfer = -1 ;
		$counttransfersecend = 0 ;
	    return 0 ;
	  } // 歸零 
	  
	} // Transfer()
	
	
	
	
	function MachineStatus( &$dataarray, $startsecend, $speed, $lastspeed, &$workstartornot ) { // 現在所有資料、現在秒數、現在速度、十秒速度陣列、電纜生產完沒
	  // $dataarray[0] = time
	  // $dataarray[1] = C11_I1_Meter
	  // $dataarray[2] = C11_I1_Position
	  // $dataarray[3] = C11_O1_Meter
	  // $dataarray[4] = C11_O1_Position
	  // $dataarray[5] = C11_Thermal
	  // 第一種狀況A：兩軸座皆無軸 -> 不用算
	  // 第二種狀況B：投入軸有軸，產出軸無軸
	  // 第三種狀況B：投入軸無軸，產出軸有軸
	  // 第四種狀況D：投入軸跟產出軸皆上       -> 這時候的線速直接1MIN去算
	  // 剩餘參考燈號表  	  
	  
	  
	  if ( $dataarray[2] == "0" && $dataarray[4] == "0"  ) { // 第一種狀況A：兩軸座皆無軸
	    $GLOBALS['gstarttoworkornot'] = false ;
	    return "停工中..." ;
	  } // if A
		
	  else if ( $dataarray[2] != "0" && $dataarray[4] == "0" ) {  // 第二種狀況B：投入軸有軸，產出軸無軸
	    // 接下來看產出軸與投入軸的線段判斷狀況
		$GLOBALS['gstarttoworkornot'] = true ; 
		
		if ( $dataarray[1] == "0" && $dataarray[3] == "0" ) { // 皆沒有線段
		  $workstartornot = false ;
		  return "完成所有產出工作，等待投入軸下軸即可完工。。。";
		} // if
		
		else if ( $dataarray[1] != "0" && $dataarray[3] == "0" ) { // 有投入線段無產出線段
		  if ( $workstartornot == true ) { // 上一秒的時間不為0且上一秒的產出軸還在
		    $GLOBALS['gstartoutputornot'] = false ;
		    return "整備中。。。(更換產出軸)";
	      } // if
		  
		  else // $workstartornot == false 產出玩了OR沒再產出
			return "整備中。。。(新製令下來)";
		} // else if 
		
		else if ( $dataarray[1] == "0" && $dataarray[3] != "0" ) { // 有產出線段無投入線段
		  return "投入線段已使用完畢，待產出軸生產完。。。";
		} // else if 
		
		else { // 同時有投入線段與產出線段
		  // 根本沒有有投入軸，產出軸無軸且同時都有線段的狀況 ( 照理說產出軸無軸就不該有產出線段了 )
		  return "異常狀況發生！！";
		} // else
		
	  } // else if 
	  
	  else if ( $dataarray[2] == "0" && $dataarray[4] != "0" ) {  // 第三種狀況C：投入軸吳軸，產出軸有軸
	    // 這種狀況一定是還在進行生產然後更換投入軸，不然就是異常狀況了 
	    if ( $dataarray[1] == "0" && $dataarray[3] == "0" ) { // 皆沒有線段 
		  // 同時都需要換軸的可能在這
		  return "整備中。。。(更換投入軸 更換產出軸中)";
		} // if
		
		else if ( $dataarray[1] == "0" && $dataarray[3] != "0" ) { //只有產出軸有線段
		  // 那就是投入的線段已用完但還要繼續產出的時候
		  return "異常狀況發生！！";
		  // return "整備中。。。(更換投入軸)";
		} // else if
		
		else { // 同時有投入線段與產出線段
		  return "異常狀況發生！！";
		} // else
	  } // else if 
		  
	  else { // 第四種狀況D：投入軸跟產出軸皆上
	    $GLOBALS['gstartoutputornot'] = true ;
	    if ( $dataarray[1] == "0" && $dataarray[3] == "0" ) { // 皆沒有線段
		  // 沒有這種狀況@@
		  return "異常狀況發生！！！";
		} // if
		
		else if ( $dataarray[1] != "0" && $dataarray[3] == "0" ) { // 有投入線段無產出線段
		  return "生產中。。。(線速未知)"; 
		} // else if 
		
		else if ( $dataarray[1] == "0" && $dataarray[3] != "0" ) { // 有產出線段無投入線段 
		  // 需要判斷增速降速均素
		  return "完成所有產出工作，等待投入軸以及產出軸下軸即可完工。。。";
		  //return SpeedStatus( $lastspeed );
		} // else if 
		
		else { // 同時有投入線段與產出線段
		  // 需要判斷增速降速均素
		  return SpeedStatus( $lastspeed, $dataarray, $startsecend );
		} // else
	    
	  }  // else if 
	  
	} // MachineStatus()
	
	
	function SpeedStatus( $lastspeed, $dataarray, $startsecend ) {
	  // 如果線速10S內變動不超過400 hr / m 又持續升速，且低於1200(+-100)的話就是穩定升速
      // 如果線速10S內變動不超過400 hr / m 又持續降速，且低於1200(+-100)的話就是降速 
	  // 會進入到這個函數的時候產出軸與投入軸都是有軸的！
	  
	  
	  
	  if ( $startsecend > 19 ) {
	    if ( $lastspeed[19] < 1100 ) { // 提速OR降速
	      if ( $lastspeed[0] > $lastspeed[19] ) { // 降速
		    if ( $lastspeed[9] - $lastspeed[19] > 400 )
		      return "異常降速！";
		    else return "穩定降速中。。。";
		  } // if $lastspeed[0] > $lastspeed[19]
		  
		  else if ( $lastspeed[0] < $lastspeed[19] ) {
			if ( $lastspeed[19] - $lastspeed[9] > 400 )
		      return "異常升速！";
		    else return "穩定增速中。。。";
		  } // else if $lastspeed[0] < $lastspeed[19]
			  
		  else { // else $lastspeed[0] == $lastspeed[19]
		    return "穩定生產狀態。。。";
		  } // else $lastspeed[0] == $lastspeed[19]
		  
		} // if 提速OR降速
		
		else if ( $lastspeed[19] > 1100 ) {
	      if ( $lastspeed[19] > 1300 ) return "線速過高！";
		  else return "穩定生產狀態。。。";
		} // else if 
		
		else if ( $lastspeed[19] == 0 && $lastspeed[0] == 0 )
		  echo "special...";
	  } // if 
	  
	  else return "生產中。。。(線速未知)" ;
	 
	} // SpeedStatus()
	
	function UpdateTenSpeed( $speed, &$speedarray ) {
	  $i = 0 ;
	  while ( $i < 19 ) { // 10個裡面往左邊移動 0~8 
	    $speedarray[$i] = $speedarray[$i+1] ;
		$i++;
	  } // while
	  
	  
	  $speedarray[19] = $speed ; // 最新的一筆速度資料
	} // UpdateTenSpeed()
	
	
	function Signal( $machinestatus ) {
	  if ( $machinestatus == "完成所有產出工作，等待投入軸下軸即可完工。。。" || 
	       $machinestatus == "完成所有產出工作，等待投入軸以及產出軸下軸即可完工。。。" ||
	       $machinestatus == "整備中。。。(更換產出軸)" ||
           $machinestatus == "整備中。。。(新製令下來)" ||	
           $machinestatus == "投入線段已使用完畢，待產出軸生產完。。。" ||
           $machinestatus == "整備中。。。(更換投入軸 更換產出軸中)" ||
           $machinestatus == "整備中。。。(更換投入軸)" ||
           $machinestatus == "生產中。。。(線速未知)" ||	
           $machinestatus == "穩定增速中。。。" ||	
           $machinestatus == "穩定降速中。。。" ||	
           $machinestatus == "穩定生產狀態。。。" )
	    return "GREEN" ;
		
	  else if ( $machinestatus == "線速過低！" ||
	            $machinestatus == "異常升速！" ||
				$machinestatus == "異常降速！" ||
				$machinestatus == "線速過高！" )
	    return "YELLOW" ; 
		
	  else if ( $machinestatus == "停工中..." )
		return "RED" ;
	  else 
	    return "PURPLE" ;
	} // function
	
	
	function ErrorLog( $machinestatus, $temper, $transfer,
                       &$machinerecord, &$temperrecord, &$transferrecord, 
					   &$errorstatus  , &$errortemper, &$errortrans,
					   $dataarray, $lastspeed, $countmeter ) {
	  // 機台狀態的部分
	  if ( Signal( $machinestatus ) == "YELLOW" || 
	       Signal( $machinestatus ) == "PURPLE" ) {
		if ( $machinerecord == "null" ) {
	      $machinerecord = $dataarray[0]; // 紀錄時間 及當時的機台狀態
		  $errorstatus = $machinestatus ;
		} // if
      } // if
	  
	  else { // 機台異常狀況解除 OR 上一秒根本沒異常狀況
	    if ( $machinerecord != "null" ) { // 上一秒有狀況
		  
		  InsertToSql ( $machinerecord, $dataarray[0], $errorstatus, $lastspeed[8] ) ;
		  $machinerecord = "null" ; // 把毛RESET
		  $errorstatus = "null";
		} // if
	  } // else 
		  
	  
	  
	  // 溫度部分
	  if ( $temper > 120 ) {
		if ( $temperrecord == "null" ) {
	      $temperrecord = $dataarray[0]; // 紀錄溫度 及當時的時間
		  $errortemper = $temper ;
		} // if
      } // if
	  
	  else { // 機台異常狀況解除 OR 上一秒根本沒異常狀況
	    if ( $temperrecord != "null" ) { // 上一秒有狀況
		  
		  InsertToSql ( $temperrecord, $dataarray[0], "溫度過高", $errortemper ) ; 
		  $temperrecord = "null" ; // 把毛RESET
		  $errortemper = "null";
		} // if
	  } // else 
		  
	  
	  
	  
	  if ( $dataarray[2] != "0" && $dataarray[4] != "0" && $lastspeed[9] > 400 && $countmeter != -1 
	       && $transfer > 0 ) {
	    // 轉換率部分
	    if ( $transfer < 5.85 || $transfer > 6.01 ) {
		  if ( $transferrecord == "null" ) {
	        $transferrecord = $dataarray[0]; // 紀錄轉換率 及當時的時間
		    $errortrans = $transfer ;
		  } // if
        } // if
	  
	    else { // 機台異常狀況解除 OR 上一秒根本沒異常狀況
	      if ( $transferrecord != "null" ) { // 上一秒有狀況
		    if ( $errortrans > 6.01 ) 
		      InsertToSql ( $transferrecord, $dataarray[0], "轉換率過高", $errortrans ) ; // 
		    else if ( $errortrans < 5.85 )
			  InsertToSql ( $transferrecord, $dataarray[0], "轉換率過低", $errortrans ) ;
		    $transferrecord = "null" ; // 把毛RESET
		    $errortrans = "null";
		  } // if
	    } // else 
	  } // if $dataarray[2] != "0" && $dataarray[4] != "0"
  
 
      
	} // ErrorLog()

   	function InsertToSql ( $starttime, $endtime, $event, $errordata ) {
	  set_time_limit(0); // 不受時間限制
      $link = mysqli_connect ( 'localhost' , 'root' , '1234' ) ;
	  mysqli_select_db($link, 'sa'); 	
		
	  $date = date("Y-m-d"); // 今天日期 ( ex : 2015-12-07 ) ;
	  $sql = "INSERT INTO `errorlog` (`Date`, `StartTime`, `EndTime`, `Event`, `Errordata`) 
		         VALUES ('$date', '$starttime', '$endtime', '$event', '$errordata' ) " ;
							
	  if ( mysqli_query( $link, $sql ) == false ) // 如果輸入資料庫失敗
	    echo "Something Wrong...<br>";
	} // InsertToSql()

	
  ?>
  
      <?php 
	  // main()
	  $startsecend = 0 ; // 讀取資料用開始的秒數
	  $endsecend = 3601 ;   // 讀取資料用結束的秒數
	  $speedsecend = 0 ;    // 線速秒數計算
	  $dataarray = array(); // 準備存進SQL的陣列
	  $countmeter = -1;      // 計算線速用
	  $speed = 0.0 ; // 線速
	  $lastspeed = array(); // 上十秒的線速
	  $lastspeedindex = 0 ; // 上十秒線速INDEX
	  $insert = true; // 要不要匯入資料庫
	  $workstartornot = false ; // 如果整個線段開始生產了就設為true，產玩了則FALSE
	  $inputmeter = -1 ; // 計算轉換率用
	  $inputmetersecend = 0 ; // 轉換率秒速計算
      $speedsum = 0 ; // 轉換率要用
	  $transfer = 0.0 ;
	  $counttransfersecend = 0 ; 
	  $outputmeter = -1 ;
	  $signal = "RED" ;
	  $machinerecord = "null";
	  $temperrecord = "null";
	  $transferrecord = "null" ;
	  $errorstatus  = "null" ; 
	  $errortemper = "null" ;
	  $errortrans = "null" ;
	  global $gstarttowork; // 工時
	  global $gstarttoworkornot; 
	  global $gstartoutput; // 產出開工後
	  global $gstartoutputornot;
	  
	  // 想顯示的有：
	  // 機台狀態( 內容只有線速穩不穩定、整備中停工中之類 ) ，溫度狀態，線速狀態，轉換率狀態，燈號
	  
	  set_time_limit(0); // 不受時間限制
      $link = mysqli_connect ( 'localhost' , 'root' , '1234' ) ;
	  mysqli_select_db($link, 'sa'); 
	  mysqli_query( $link, "set names 'utf8'" );//寫庫 
	  
	  
	  ob_end_flush(); // 顯示用
	  while ( $startsecend < $endsecend ) {
	    // Machine( $dataarray, $startsecend, $insert) ;
		Simulation( $dataarray, $startsecend ) ;
		
		/*
		if ( $startsecend != 0 ) {
		  // Machine( $lastdataarray, $startsecend - 1, false ) ; // 抓取上一秒資料用
		} // if
        */
		
        $speed = Speed( $dataarray, $countmeter, $speed, $speedsecend, $workstartornot, $startsecend );
		
		// 把算好的線速存到資料庫
		$sql = " INSERT INTO `speed` (`Time`, `speed` ) 
		         VALUES ( '$dataarray[0]', '$speed' ) " ;  
		if ( mysqli_query( $link, $sql ) == false )
		  echo "Insert Speed Error!!!...<br>";
		flush();
		
		// 把秒數輸入進lastspeed陣列裡
		if ( $lastspeedindex < 20 ) { // 未記錄完前十筆線速資料
		  $lastspeed[$lastspeedindex] = $speed;
		  $lastspeedindex++;
		} // if		
		else // 已經滿了就更新那10秒的陣列到最新
		  UpdateTenSpeed( $speed, $lastspeed );
		  
		// $transfer = Transfer( $dataarray, $inputmeter, $outputmeter, $transfer ) ;
		$transfer = Transfer( $dataarray, $inputmeter, $inputmetersecend, $speedsum, $startsecend, $transfer, $counttransfer, $counttransfersecend ) ;
		// echo"目前轉換率為1:".$transfer."<br>" ;  
		  
		
		// echo "目前線速為".$speed." m / hr<br>" ;
		$status = MachineStatus( $dataarray, $startsecend, $speed, $lastspeed, $workstartornot ) ;
		// InsertStatusToSql ( $dataarray[0], $status ) ;
		// InsertTransferToSql ( $dataarray[0], $transfer ) ;
		$signal = Signal( $status ) ;
		flush();
		/*
		$sql = " INSERT INTO `C11` (`Time`, `status`, `C11_I1_Meter`, `C11_I1_Position`, `C11_O1_Meter`, `C11_O1_Position`, `C11_Thermal`, `speed`, `transfer`, `light` ) 
		         VALUES ( '$dataarray[0]', '$status', '$dataarray[1]', '$dataarray[2]', '$dataarray[3]', '$dataarray[4]', '$dataarray[5]', '$speed', '$transfer', '$signal' ) " ;  
		if ( mysqli_query( $link, $sql ) == false )
		      echo "Insert Error!!!...<br>";
		  
		ErrorLog( $status, $dataarray[5], $transfer,
                       $machinerecord, $temperrecord,  $transferrecord, 
					   $errorstatus  , $errortemper, $errortrans,
					   $dataarray, $lastspeed, $countmeter ) ;
		*/
	?>
    <script>
      function Show() {//顯示下一筆資料
	    var light = '<?php echo $signal ?>' ;
        document.getElementById('temper').innerHTML="<?php echo $dataarray[5];?>";   
        document.getElementById('speed').innerHTML="<?php echo $speed;?>";	
        document.getElementById('transfer').innerHTML="<?php echo "轉換率  ".$transfer;?>";
        document.getElementById('input').innerHTML="<?php echo "投入軸型號  ".$dataarray[2];?>";
        document.getElementById('inputmeter').innerHTML="<?php echo "投入軸計米  ".$dataarray[1];?>";
        document.getElementById('output').innerHTML="<?php echo "產出軸型號  ".$dataarray[4];?>";
        document.getElementById('outputmeter').innerHTML="<?php echo "產出軸計米  ".$dataarray[3];?>";
        document.getElementById('status').innerHTML="<?php echo $status;?>";
        document.getElementById('time').innerHTML="<?php echo "時間  ".$dataarray[0];?>";
		
        if ( light == "RED" )	 
          document.getElementById('light').innerHTML="<img id='lightball' src='img/red.png'>";	
        else if ( light == "YELLOW" ) 	  
		  document.getElementById('light').innerHTML="<img id='lightball' src='img/yellow.png'>";
	    else if ( light == "GREEN" ) 	  
		  document.getElementById('light').innerHTML="<img id='lightball' src='img/green.png'>";
	    else if ( light == "PURPLE" ) 	  
		  document.getElementById('light').innerHTML="<img id='lightball' src='img/purple.png'>";
      } // Show()
   	</script>
	<?php
	//顯示用部分
		echo "<script> Clear() </script>";	 
		flush();
		echo "<script> Show() </script>"; // 顯示用 
		flush();
		//sleep( 1 ); // 暫停0.5秒
		
		
		// 工時部分
        if ( $GLOBALS['gstarttoworkornot'] == true ) // 開始上軸動工了
		  $GLOBALS['gstarttowork']++;
		if ( $GLOBALS['gstartoutputornot'] == true ) // 開始
		  $GLOBALS['gstartoutput']++;
		else {
	      $GLOBALS['gstartoutput'] = 0 ;
		} // else
		
		  
	    if ( $dataarray[0] == "01:00:00" ) {
	     echo "工時：".Dataformat( $GLOBALS['gstarttowork'] );
	    } // if  
		
		
		
        $startsecend++;		
		FormatArray( $dataarray ) ; // 清空陣列	
	} // while		
	
	// main() end
	?> 






       
</body>
                                
</html>
