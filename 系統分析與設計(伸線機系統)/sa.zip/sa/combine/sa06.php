<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title></title>
		<link rel=stylesheet type="text/css" href="css/sa5.css">
	</head>
	<body style="color:white">
	<?php
    $link = mysqli_connect ( 'localhost' , 'root' , '1234' ) ;
	mysqli_select_db($link, 'sa'); 
	//mysqli_query($link, "set names 'utf8'");
	$sql = "SELECT * FROM `errorlog`";
    $forerrortemp = mysqli_query( $link, $sql ) ;
	  if ( $forerrortemp == false )
        echo "SELECT Error!!!...<br>";
	  while ( $row = mysqli_fetch_array( $forerrortemp ) ) {
		  echo "=============================================<br>";
        echo "日期：".$row['Date'] . " <br><br>  " . "時間：".$row['StartTime'] . " ~ " . $row['EndTime'] . "  <br><br> " . 
		     "事件：".$row['Event'] . "  <br><br> " . "數值：".$row['Errordata'] ;
        echo "<br />";
		echo "=============================================<br>";
      } // while
      //$fortranstemp = $speedtemp['Event']; // 到這行為止才抓到現在的線速資料
  ?>
</body>
</html>