<html>
<head>
<script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js"></script>
<meta http-equiv="refresh" content="10">
</head>
<body>
<div style="width:1200px; font-size:500px" id="chart">
  <canvas id="myChart"></canvas>
</div>
<?php
    $link = mysqli_connect ( 'localhost' , 'root' , '1234' ) ;
	mysqli_select_db($link, 'sa'); 
	$arraylist = array();
	$arraylist2 = array();
	//mysqli_query($link, "set names 'utf8'");
	$sql = "SELECT * FROM `c11`";
	$i = 0 ;
    $forerrortemp = mysqli_query( $link, $sql ) ;
	  if ( $forerrortemp == false )
        echo "SELECT Error!!!...<br>";
	  while ( $row = mysqli_fetch_array( $forerrortemp ) ) {
		
        $arraylist[$i] = $row['speed'];
		$arraylist2[$i] = $row['Time'];
		$i++;
      } // while
	  
?>
	<script>
var ctx = document.getElementById('myChart').getContext('2d');
var jsprint = <?php echo json_encode( $arraylist ) ?> ;
var jsprint2 = <?php echo json_encode( $arraylist2 ) ?> ;
    Chart.defaults.global.defaultFontFamily = "Microsoft JhengHei";
	Chart.defaults.global.defaultFontSize = 30;
	Chart.defaults.global.defaultFontColor = 'blue';
var chart = new Chart(ctx, {
    // The type of chart we want to create
    type: 'line',

    // The data for our dataset
    data: {
        labels: jsprint2,
        datasets: [{
            label: "線速與時間",
            backgroundColor: [
          'rgba(65, 129, 129, 1)',
          'rgba(75, 192, 192, 0.2)',
          'rgba(255, 99, 132, 0.2)',
          'rgba(54, 162, 235, 0.2)',
          'rgba(255, 206, 86, 0.2)',
          'rgba(153, 102, 255, 0.2)'
        ],
            borderColor: [
          'rgba(65, 129, 129, 1)',
          'rgba(75, 192, 192, 0.2)',
          'rgba(255, 99, 132, 0.2)',
          'rgba(54, 162, 235, 0.2)',
          'rgba(255, 206, 86, 0.2)',
          'rgba(153, 102, 255, 0.2)'
        ],
            data: jsprint,
			
        }]
		  
    },

    // Configuration options go here
        options: {
			
        animation: {
            duration: 0, // general animation time
        },
        hover: {
            animationDuration: 0, // duration of animations when hovering an item
        },
        responsiveAnimationDuration: 0, // animation duration after a resize
		
		
		      scales: {
		animation: false,
        yAxes: [{
          ticks: {
			fontSize: 20,
            beginAtZero:true,
          }
        }]
		
		
      }
    }
});
</script>
</body>
</html>