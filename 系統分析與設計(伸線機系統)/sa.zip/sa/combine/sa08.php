<!DOCTYPE html>
<html>
	<head>
		
		<title></title>
		<link rel=stylesheet type="text/css" href="css/sa6.css">
		
	</head>
	<body style="color:white">
	<?php
	header("Content-Type:text/html; charset=utf-8");
    $link = mysqli_connect ( 'localhost' , 'root' , '1234' ) ;
		mysqli_query($link, 'set names utf8');
	mysqli_select_db($link, 'sa'); 
	//mysqli_query($link, "set names 'utf8'");
	$sql = "SELECT * FROM `c11`";
    $forerrortemp = mysqli_query( $link, $sql ) ;
	mysqli_set_charset ($link,"utf8");
	  if ( $forerrortemp == false )
        echo "SELECT Error!!!...<br>";
	echo "==========================================================================================================<br>"; 
	  while ( $row = mysqli_fetch_array( $forerrortemp ) ) {
		  
        echo "|| 時間".$row['Time'] . " ||  " . "機台狀態：".$row['status'] . " || 投入軸 ：" . 
		         $row['C11_I1_Position'] . " || 投入計米 ：" .  $row['C11_I1_Meter'] . " || 產出軸： ".
				 $row['C11_O1_Position'] . " || 投入計米 ：" .  $row['C11_O1_Meter'] . " || 溫度： ".
                 $row['C11_Thermal'] . " || 線速 ：".  $row['speed']  . " || 轉換率：" .  $row['transfer'].
                 " || 燈號：". $row['light'];				 
        echo "<br><br>";
		
      } // while
	  echo "=============================================<br>";
      //$fortranstemp = $speedtemp['Event']; // 到這行為止才抓到現在的線速資料
  ?>
</body>
</html>