<html>
  <head>
  <?php
    $link = mysqli_connect ( 'localhost' , 'root' , '1234' ) ;
	mysqli_select_db($link, 'sa'); 
	$sql = "SELECT * FROM `errorlog`";
    $forerrortemp = mysqli_query( $link, $sql ) ;
	  if ( $forerrortemp == false )
        echo "SELECT Error!!!...<br>";
	  //$errortemp = mysqli_fetch_array( $forerrortemp ) ;
	  while ( $row = mysqli_fetch_array( $forerrortemp ) ) {
        echo $row['Date'] . " " . $row['Event'];
        echo "<br />";
		//$fortranstemp = $speedtemp['Event']; // 到這行為止才抓到現在的線速資料
	    //echo $fortranstemp ;
      } // while
      //$fortranstemp = $speedtemp['Event']; // 到這行為止才抓到現在的線速資料
  ?>
  </head>
  <body>
  </body>
</html>